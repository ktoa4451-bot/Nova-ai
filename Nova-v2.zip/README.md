# Nova AI Studio
1. Ollama (ollama.com): `ollama pull qwen2.5-coder:7b` — бесплатно и без лимитов.
2. ПК: `npm install && npm start`, либо .exe из GitHub Actions (Nova-Windows).
3. Вкладка «Обучение» → «Создать Nova-Coder» — модель с зашитым кодерским промптом и базой знаний.
4. Телефон: APK из Actions (Nova-Android). При запуске введи http://IP-ПК:8787. Управление ПК с телефона отключено.
Мышь/клавиатура/скриншоты работают на Windows (PowerShell). Для скриншотов нужна модель с vision (например llava).
