package com.nova.app;
import android.app.Activity;import android.app.AlertDialog;import android.content.SharedPreferences;import android.os.Bundle;
import android.webkit.*;import android.widget.EditText;
public class MainActivity extends Activity{
 WebView w;SharedPreferences p;
 protected void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("n",0);w=new WebView(this);setContentView(w);
  WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  w.setWebViewClient(new WebViewClient(){public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())ask();}});
  w.addJavascriptInterface(new Object(){@JavascriptInterface public void changeServer(){runOnUiThread(new Runnable(){public void run(){ask();}});}},"Android");
  String u=p.getString("u","");if(u.isEmpty())ask();else w.loadUrl(u);}
 void ask(){final EditText e=new EditText(this);e.setText(p.getString("u","http://192.168.0.10:8787"));
  new AlertDialog.Builder(this).setTitle("Адрес Nova на ПК").setView(e).setCancelable(false)
  .setPositiveButton("OK",(d,i)->{String u=e.getText().toString().trim();if(!u.startsWith("http"))u="http://"+u;p.edit().putString("u",u).apply();w.loadUrl(u);}).show();}
 public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}}
