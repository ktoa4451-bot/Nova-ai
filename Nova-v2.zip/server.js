const http=require('http'),fs=require('fs'),path=require('path'),os=require('os'),{exec}=require('child_process'),AdmZip=require('adm-zip');
const D=process.env.NOVA_DATA||path.join(__dirname,'data'),W=path.join(D,'workspace');
fs.mkdirSync(W,{recursive:true});
const rj=(f,d)=>{try{return JSON.parse(fs.readFileSync(path.join(D,f),'utf8'))}catch{return d}};
const wj=(f,v)=>fs.writeFileSync(path.join(D,f),JSON.stringify(v,null,1));
const F='`'.repeat(3);
const EF={low:{n:768,t:.7,p:'Answer briefly and directly.'},medium:{n:2048,t:.5,p:''},high:{n:4096,t:.3,p:'Think step by step and plan before acting.'},max:{n:8192,t:.15,p:'Reason very carefully, plan, then verify your work with tools before finishing.'}};
const SYS='You are Nova, an expert senior software engineer and autonomous agent running on the user PC. Reply in the language of the user.\n'+
'Act by writing tool blocks (several per message are allowed):\n'+F+'tool\n{"name":"write_file","path":"app/index.js","content":"..."}\n'+F+'\n'+
'Tools: write_file{path,content} read_file{path} list{} run{cmd} zip{out,dir} move{from,to} copy{from,to} delete{path} web_search{query} web_fetch{url} mouse{action:move|click|rightclick|doubleclick|scroll,x,y,amount} type{text} key{keys in SendKeys format e.g. ^c or {ENTER}} screenshot{} open{target}.\n'+
'Relative paths are in the workspace; absolute paths and "~" work for move/copy/delete/read_file only when PC control is on. Rules: write complete working code, no placeholders; verify with run when possible; when a project is finished add README and .github/workflows/build.yml when CI applies, then zip it. Use web_search/web_fetch if unsure about an API or version. Take a screenshot before mouse work to learn the screen size.';
const seed=[
{title:'Стиль кодинга',text:'Полный рабочий код без заглушек и TODO. Структура: README, исходники, конфиг сборки. Обрабатывай ошибки, понятные имена. После написания проверяй: JS — node --check файл, Python — python -m py_compile, Java — gradle build. Исправляй ошибки сам и повторяй.'},
{title:'GitHub Actions шаблоны',text:'Всегда клади .github/workflows/build.yml в проект и в ZIP. Electron: windows-latest, setup-node 20, npm install, npx electron-builder --win. Android: ubuntu-latest, setup-java 17, gradle/actions/setup-gradle, gradle assembleDebug. Fabric/Java мод: setup-java 21, ./gradlew build, upload build/libs/*.jar. Python exe: pip install pyinstaller, pyinstaller --onefile.'},
{title:'Fabric моды',text:'Fabric: fabric.mod.json, Java 21, fabric-loom, клиентские моды через ClientModInitializer, миксины в *.mixins.json. Версию API проверяй через web_search.'},
{title:'Поведение агента',text:'Сначала короткий план, затем действия инструментами. Если непонятна версия библиотеки или API — web_search. Для мыши сначала screenshot. Перед удалением или перезаписью чужих файлов предупреждай пользователя. В конце коротко опиши, что сделано и где лежат файлы.'}];
if(!fs.existsSync(path.join(D,'knowledge.json')))wj('knowledge.json',seed);
const walk=(d,b=d)=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name),b):[path.relative(b,path.join(d,e.name))]);
const safe=p=>{const f=path.resolve(W,p||'.');if(!f.startsWith(W))throw Error('outside workspace');return f};
const P=(p,c)=>{p=String(p||'.');if(p.startsWith('~'))p=path.join(os.homedir(),p.slice(1));if(path.isAbsolute(p)){if(!c)throw Error('PC control is disabled');return p}return safe(p)};
const strip=s=>s.replace(/<[^>]+>/g,'').replace(/&amp;/g,'&').replace(/&#x27;/g,"'").replace(/&quot;/g,'"').replace(/\s+/g,' ').trim();
const ps=code=>new Promise(r=>{const f=path.join(os.tmpdir(),'nova'+Date.now()+'.ps1');fs.writeFileSync(f,code);exec('powershell -NoProfile -ExecutionPolicy Bypass -File "'+f+'"',{timeout:20000},(e,o,er)=>{fs.unlink(f,()=>{});r((o+er+(e?e.message:'')).trim()||'ok')})});
const PSH='Add-Type -AssemblyName System.Windows.Forms,System.Drawing\nAdd-Type @"\nusing System.Runtime.InteropServices;\npublic class M{[DllImport("user32.dll")]public static extern void mouse_event(int f,int x,int y,int d,int e);}\n"@\n';
const defS={type:'ollama',url:'http://localhost:11434',key:'',control:true};
async function llm(s,model,msgs,ef){
 const e=EF[ef]||EF.medium;
 if(s.type==='openai'){const r=await fetch(s.url+'/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+s.key},body:JSON.stringify({model,messages:msgs.map(({role,content})=>({role,content})),temperature:e.t,max_tokens:e.n})});return (await r.json()).choices[0].message.content}
 const r=await fetch(s.url+'/api/chat',{method:'POST',body:JSON.stringify({model,messages:msgs,stream:false,options:{temperature:e.t,num_predict:e.n,num_ctx:8192}})});const j=await r.json();if(j.error)throw Error(j.error);return j.message.content}
async function tool(t,c){
 const n=t.name;
 if(n==='write_file'){const f=safe(t.path);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,t.content);return {text:'ok '+t.path}}
 if(n==='read_file')return {text:fs.readFileSync(P(t.path,c),'utf8').slice(0,8000)};
 if(n==='list')return {text:walk(W).join('\n')||'(empty)'};
 if(n==='zip'){const o=t.out||'project.zip';const z=new AdmZip();z.addLocalFolder(safe(t.dir||'.'));z.writeZip(safe(o.endsWith('.zip')?o:o+'.zip'));return {text:'zip ready: '+o}}
 if(n==='web_search'){const h=await(await fetch('https://html.duckduckgo.com/html/?q='+encodeURIComponent(t.query),{headers:{'User-Agent':'Mozilla/5.0'}})).text();
  return {text:[...h.matchAll(/class="result__a" href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g)].slice(0,6).map(m=>strip(m[2])+'\n'+decodeURIComponent((m[1].match(/uddg=([^&]+)/)||[0,m[1]])[1])+'\n'+strip(m[3])).join('\n\n')||'no results'}}
 if(n==='web_fetch'){const h=await(await fetch(t.url,{headers:{'User-Agent':'Mozilla/5.0'}})).text();return {text:strip(h.replace(/<(script|style)[\s\S]*?<\/\1>/g,'')).slice(0,6000)}}
 if(!c)return {text:'PC control is disabled here (only the PC itself with control enabled)'};
 if(n==='run')return new Promise(r=>exec(t.cmd,{cwd:W,timeout:120000},(e,o,er)=>r({text:(o+er+(e?e.message:'')).slice(0,4000)||'ok'})));
 if(n==='move'){const a=P(t.from,c),b=P(t.to,c);fs.mkdirSync(path.dirname(b),{recursive:true});try{fs.renameSync(a,b)}catch{fs.cpSync(a,b,{recursive:true});fs.rmSync(a,{recursive:true})}return {text:'moved'}}
 if(n==='copy'){const b=P(t.to,c);fs.mkdirSync(path.dirname(b),{recursive:true});fs.cpSync(P(t.from,c),b,{recursive:true});return {text:'copied'}}
 if(n==='delete'){fs.rmSync(P(t.path,c),{recursive:true});return {text:'deleted'}}
 if(n==='open')return new Promise(r=>exec('start "" "'+t.target+'"',(e)=>r({text:e?e.message:'opened'})));
 if(n==='mouse'){const x=+t.x||0,y=+t.y||0,a=t.action||'click';const clk=(d,u)=>`[M]::mouse_event(${d},0,0,0,0);[M]::mouse_event(${u},0,0,0,0);`;
  const act=a=='move'?'':a=='click'?clk(2,4):a=='rightclick'?clk(8,16):a=='doubleclick'?clk(2,4)+clk(2,4):`[M]::mouse_event(2048,0,0,${+t.amount||-120},0);`;
  return {text:await ps(PSH+`[System.Windows.Forms.Cursor]::Position=New-Object System.Drawing.Point(${x},${y})\nStart-Sleep -Milliseconds 80\n`+act)}}
 if(n==='type')return {text:await ps(PSH+`[System.Windows.Forms.SendKeys]::SendWait('${String(t.text).replace(/[+^%~(){}\[\]]/g,'{$&}').replace(/'/g,"''")}')`)};
 if(n==='key')return {text:await ps(PSH+`[System.Windows.Forms.SendKeys]::SendWait('${String(t.keys).replace(/'/g,"''")}')`)};
 if(n==='screenshot'){const f=path.join(W,'screenshot.png');const o=await ps(PSH+`$b=[System.Windows.Forms.SystemInformation]::VirtualScreen\n$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height\n$g=[System.Drawing.Graphics]::FromImage($bmp)\n$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size)\n$bmp.Save('${f}')\n"screen $($b.Width)x$($b.Height)"`);
  return {text:o+' saved screenshot.png',image:fs.existsSync(f)?fs.readFileSync(f).toString('base64'):null}}
 return {text:'unknown tool '+n}}
const body=q=>new Promise(r=>{let b='';q.on('data',c=>b+=c);q.on('end',()=>{try{r(JSON.parse(b||'{}'))}catch{r({})}})});
http.createServer(async(q,res)=>{
 const local=['127.0.0.1','::1','::ffff:127.0.0.1'].includes(q.socket.remoteAddress);
 const js=(o,c=200)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
 const s={...defS,...rj('settings.json',{})};const u=q.url.split('?')[0];const C=local&&s.control;
 try{
 if(u==='/')return res.end(fs.readFileSync(path.join(__dirname,'renderer','index.html')));
 if(u==='/api/info')return js({local,ips:Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).map(i=>i.address)});
 if(u==='/api/settings'){if(q.method==='POST'){if(!local)return js({},403);wj('settings.json',{...s,...await body(q)});return js({ok:1})}return js(s)}
 if(u==='/api/models'){if(s.type==='openai'){const j=await(await fetch(s.url+'/models',{headers:{Authorization:'Bearer '+s.key}})).json();return js(j.data.map(m=>m.id))}const j=await(await fetch(s.url+'/api/tags')).json();return js(j.models.map(m=>m.name))}
 if(u==='/api/create'){if(!local)return js({error:'only on PC'},403);const b=await body(q),k=rj('knowledge.json',[]).map(x=>x.title+': '+x.text).join('\n');
  const r=await fetch(s.url+'/api/create',{method:'POST',body:JSON.stringify({model:b.name||'nova-coder',from:b.base,system:SYS+'\nKnowledge base:\n'+k,parameters:{temperature:.3,num_ctx:8192},stream:false})});return js(await r.json())}
 if(u==='/api/knowledge'){let k=rj('knowledge.json',[]);if(q.method==='POST'){const b=await body(q);if(b.del!=null)k.splice(b.del,1);else k.push({title:b.title,text:b.text});wj('knowledge.json',k)}return js(k)}
 if(u==='/api/sample'){const b=await body(q);fs.appendFileSync(path.join(D,'train.jsonl'),JSON.stringify({messages:[{role:'user',content:b.prompt},{role:'assistant',content:b.response}]})+'\n');return js({n:fs.readFileSync(path.join(D,'train.jsonl'),'utf8').split('\n').length-1})}
 if(u==='/api/export'){res.writeHead(200,{'Content-Disposition':'attachment; filename=train.jsonl'});return res.end(fs.existsSync(path.join(D,'train.jsonl'))?fs.readFileSync(path.join(D,'train.jsonl')):'')}
 if(u==='/api/files')return js(walk(W));
 if(u.startsWith('/files/')){res.writeHead(200,{'Content-Disposition':'attachment'});return res.end(fs.readFileSync(safe(decodeURIComponent(u.slice(7)))))}
 if(u==='/api/chat'){
  const b=await body(q),k=rj('knowledge.json',[]).map(x=>x.title+': '+x.text).join('\n');
  const sys=SYS+(k?'\nKnowledge base:\n'+k:'')+'\n'+(EF[b.effort]||EF.medium).p+'\nPC control: '+(C?'ON (Windows)':'OFF');
  let msgs=[{role:'system',content:sys},...b.messages],stop=false;res.on('close',()=>stop=true);
  res.writeHead(200,{'Content-Type':'application/x-ndjson'});const out=o=>res.write(JSON.stringify(o)+'\n');
  try{for(let i=0;i<(b.agent?10:1)&&!stop;i++){
   const o=await llm(s,b.model,msgs,b.effort);out({role:'assistant',content:o});msgs.push({role:'assistant',content:o});
   const ts=[...o.matchAll(/```tool\n([\s\S]*?)```/g)];if(!ts.length||!b.agent)break;
   const rs=[];let img=null;for(const m of ts){try{const r=await tool(JSON.parse(m[1]),C);rs.push(r.text);if(r.image)img=r.image}catch(e){rs.push('error: '+e.message)}}
   const c='Tool results:\n'+rs.join('\n---\n');out({role:'tool',content:c});msgs.push(img&&s.type==='ollama'?{role:'user',content:c,images:[img]}:{role:'user',content:c})}
  }catch(e){out({role:'tool',content:'Ошибка: '+e.message})}
  return res.end()}
 js({error:'not found'},404)}catch(e){js({error:e.message},500)}
}).listen(8787,'0.0.0.0');
