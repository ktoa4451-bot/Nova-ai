const {app,BrowserWindow}=require('electron');
process.env.NOVA_DATA=app.getPath('userData');
require('./server');
app.whenReady().then(()=>{const w=new BrowserWindow({width:1100,height:760,title:'Nova',autoHideMenuBar:true});w.loadURL('http://localhost:8787')});
app.on('window-all-closed',()=>app.quit());
